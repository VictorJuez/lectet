module.exports = {
  JWT_SECRET: 'lectetauthentication'
}