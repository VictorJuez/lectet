module.exports = {
    users: require('./users'),
    authors: require('./authors'),
    books: require('./books'),
    ratings: require('./ratings')
  };